<?php

if (getenv('REMOTE_USER') != 'root') 
	die('Access Denied.');
$cptoken = getenv('cp_security_token');
$plugact=$_REQUEST['plugact'];
require_once('/usr/local/cpanel/php/WHM.php');
$headerString = WHM::getHeaderString("",1,0);
echo($headerString);
 
 
$breadcrumbs_list='';
$head_title='Fix User File Permissions';
$breadcrumbs_list .='<li><a href="'.$cptoken.'/scripts/command?PFILE=main"><span class="imageNode">Home</span></a><span> &raquo; </span></li>';
$breadcrumbs_list .='<li><a uniquekey="plugins" href="'.$cptoken.'/scripts/command?PFILE=Plugins"><span>Plugins</span></a><span> &raquo; </span></li>';
$breadcrumbs_list .='<li><a uniquekey="Fixperms" href="'.$cptoken.'/cgi/Fixperms/index.php"><span>Fixperms</span></a></li>';

$list_user=shell_exec("/usr/local/cpanel/bin/whmapi1 --output=json list_users");
$list_user=json_decode($list_user,1);

 
?>

<script src="jquery/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
$("#breadcrumbs_list").html('<?php echo $breadcrumbs_list;?>');
</script>

<style>
#fixperms_form .btn-primary {
    color: #ffffff;
	outline:none;
    text-shadow: 0 -1px 0 rgb(0 0 0 / 25%);
    background-color: #0178df;
    *background-color: #135ef3;
    background-image: -moz-linear-gradient(top, #019ce9, #135ef3);
    background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#019ce9), to(#135ef3));
    background-image: -webkit-linear-gradient(top, #019ce9, #135ef3);
    background-image: -o-linear-gradient(top, #019ce9, #135ef3);
    background-image: linear-gradient(to bottom, #019ce9, #135ef3);
    background-repeat: repeat-x;
    border-color: #0044cc #0044cc #002a80;
    border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff135ef3', GradientType=0);
    filter: progid:DXImageTransform.Microsoft.gradient(enabled=false);
}


.panel-default h4{
    margin: 0 !important;
    padding: 10px;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 15px;
    font-weight: 600;
    color: #004C5F;
    text-shadow: 0 1px 0 #ffffff;
}

</style>



<div class="panel panel-default" style="margin:25px 0;">
<h4><img src="img/icon.png" style="padding-left: 15px" width="55px"> Fixperms - <?php echo $head_title;?></h4>
</div>


<?php


if($_POST['submit']=='Fix' && $_POST['userName']){

$userName=$_POST['userName'];
if($userName=="root") $userName='';

$cmd="./fix.sh -a $userName";
$output=shell_exec($cmd);


echo '<br><pre>';	
print_r($output);
echo '</pre><br>';
}

?>

<form method="POST" action="" style="margin: 10px 0 10px 10px;" id="fixperms_form">
<label>Select User</label>
<br>
<select name="userName" class="form-control" style="max-width:50%;">
<?php
foreach($list_user['data']['users'] as $user){
if($user=='root') continue;
echo '<option value="'.$user.'">'.$user.'</option>';   
}
?>	
</select>
<br>
<input type="submit" name="submit" value="Fix" class="btn btn-primary ">
</form>



<br><br>
<div class="footer" style="border-top:1px solid grey;text-align:center!important; font-size:11px;">
<b><a href="https://www.ninzahost.in" target="_blank">Fixperms</a> </b>Copyright &copy; 2020 - <?php echo date("Y");?>
<a href="" target="_blank"></a>. All rights reserved.
</div>
</div>
