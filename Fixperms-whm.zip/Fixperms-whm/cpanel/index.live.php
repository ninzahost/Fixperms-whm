<?php
if (!isset($_ENV['cp_security_token']))
	die('This file can be accessed only by CPPHP');
	
$CROOTDIR = '/usr/local/cpanel/base/3rdparty/Fixperms/';
require_once("/usr/local/cpanel/php/cpanel.php");
$livecpapi = new CPANEL();
if (isset($_GET['action'])) {$action = trim($_GET['action']);} else {$action = '';}
$userhomedir = getenv('HOME');
$username=explode('/',$userhomedir)[2];

print $livecpapi->header( "Fix File Permission" );

	print('<script type="text/javascript" src="js/jquery.min.js"></script>');


function UserTheme() {
	global $livecpapi;
	$statsbar = $livecpapi->api2('StatsBar','stat',array("display"=>"theme"));
	$cpTheme = trim($statsbar['cpanelresult']['data'][0]['value']);
	if (!empty($cpTheme)) {	
		return $cpTheme;
	} else {
		return false;
	}
}
function cpBase() {
	$UserTheme = UserTheme();
	if (isset($_ENV['cp_security_token'])) {
		$cptokuri = $_ENV['cp_security_token'].'/frontend/';
	} else {
		$cptokuri = '/frontend/';
	}
	if ($UserTheme) {
		return $cptokuri.$UserTheme.'/';
	} else {
		return false;
	}
}


function BaseDIR() {
	return $_ENV['cp_security_token'].'/3rdparty/fixpermission/';
}
function GoBackBtn($flag) {
	if ($flag == 'tostart') {
		$aID 	= 'gobacktostart';
		$aHREF 	= BaseDIR().'index.live.php';
		$aTEXT 	= 'Go Back';
	} elseif ($flag == 'tohome') {
		$aID 	= 'gobacktohome';
		$aHREF 	= cpBase().'index.html';
		$aTEXT 	= 'Go Back';
	} else {
		$aHREF 	= '#';
		$aID 	= 'cpreturnlink';
		$aTEXT 	= 'Go Back';
	} 
	echo '<div class="return-link"><a id="'.$aID.'" href="'.$aHREF.'"><span class="glyphicon glyphicon-circle-arrow-left"></span> '.$aTEXT.'</a></div>';
}







	//<label for="domain" class="col-sm-2 control-label">Domain Name</label>		
			
            echo '<form class="form-horizontal" action = "index.live.php?action=fix" method = "POST" role="form" style="width: 100%;">';
			echo '<p lass="description">
			<strong>A script to fix permissions and ownership, on files and directories, for cPanel accounts.</strong>
			</p>	<br><br>
			
			<input type="hidden" name="userName" value="'.$username.'">		
			
			<div style="width: 250px; height:70px; margin: 0 auto;"> 
			<input class="btn btn-primary" value="Fix" type="submit" style="width: 150px; height:50px; font-size: 25px;">
			</div>'; 	   
			echo "</form>";

if(isset($_POST['userName']) && $action=='fix') {

$cmd="./fix.sh -a $username";
$output=shell_exec($cmd);

echo '<pre>'."\n\n";
print($output);
echo '</pre>';


   GoBackBtn('');

}else{
   GoBackBtn('tohome');	
}





	echo '<script type="text/javascript">
		$(document).ready(function(){
		    $("#cpreturnlink").click(function(){
		        parent.history.back();
		        return false;
		    });
		});
	</script>';


print $livecpapi->footer();                      // Add the footer.
$livecpapi->end();                               // Disconnect from cPanel - only do this once.