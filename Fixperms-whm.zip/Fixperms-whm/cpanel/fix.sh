#! /bin/bash
fixperms () {
  #Get account from what is passed to the function
  account=$1
  #Check account against cPanel users file
  if [ ! grep $account /var/cpanel/users/* ]
  then
    tput bold
    tput setaf 1
    echo "Invalid cPanel account : $account"
    tput sgr0
    exit 0
  fi
 #Make sure account isn't blank
  if [ -z $account ]
  then
    tput bold
    tput setaf 1
    echo "Need an account name!"
    tput sgr0
    helptext
  #Else, start doing work
  else
 #Get the account's homedir
    HOMEDIR=$(egrep "^${account}:" /etc/passwd | cut -d: -f6)

    tput bold
    tput setaf 4
    echo "Fixing perms for $account:"
    tput setaf 3
    echo "------------------------"
    tput setaf 4
    echo "Fixing website files...."
    tput sgr0
    
    #Fix individual files in public_html
    find $HOMEDIR/public_html -type d -exec chmod 755 {} \;
    find $HOMEDIR/public_html -type f | xargs -d$'\n' -r chmod 644
    find $HOMEDIR/public_html -name '*.cgi' -o -name '*.pl' | xargs -r chmod 755
    # Hidden files support: https://serverfault.com/a/156481
    # fix hidden files and folders like .well-known/ with root or other user perms
    chown -R $account:$account $HOMEDIR/public_html/.[^.]*
    find $HOMEDIR/* -name .htaccess -exec chown $account.$account {} \;

    tput bold
    tput setaf 4
    echo "Fixing public_html...."
    tput sgr0
    #Fix perms of public_html itself
    chown $account:nobody $HOMEDIR/public_html
    chmod 750 $HOMEDIR/public_html

    #Fix subdomains that lie outside of public_html
    tput setaf 3
    tput bold
    echo "------------------------"
    tput setaf 4
    echo "Fixing any domains with a document root outside of public_html...."
    for SUBDOMAIN in $(grep -i documentroot /var/cpanel/userdata/$account/* | grep -v '.cache\|_SSL' | awk '{print $2}' | grep -v public_html)
    do
      tput bold
      tput setaf 4
      echo "Fixing sub/addon domain document root $SUBDOMAIN...."
      tput sgr0
      find $SUBDOMAIN -type d -exec chmod 755 {} \;
      find $SUBDOMAIN -type f | xargs -d$'\n' -r chmod 644
      find $SUBDOMAIN -name '*.cgi' -o -name '*.pl' | xargs -r chmod 755
      chown -R $account:$account $SUBDOMAIN
      chmod 755 $SUBDOMAIN
      find $SUBDOMAIN -name .htaccess -exec chown $account.$account {} \;
    done
  #Finished
    tput bold
    tput setaf 3
    echo "Finished!"
    echo "------------------------"
    printf "\n\n"
fi
}
case "$1" in
    -a) fixperms "$2" 
esac
exit 0